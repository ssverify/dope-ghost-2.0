#pragma once

class MovingObjectPosition
{
public:
	bool IsAimingBlock(JNIEnv* env);
	bool IsAimingEntity(JNIEnv* env);

};