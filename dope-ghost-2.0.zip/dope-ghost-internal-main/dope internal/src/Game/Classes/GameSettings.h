#pragma once

class GameSettings
{
public:
	jobject GetKeyBindSneak(JNIEnv* env);
};