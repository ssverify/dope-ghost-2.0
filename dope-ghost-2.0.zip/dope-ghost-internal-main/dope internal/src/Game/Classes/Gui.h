#pragma once

class Gui
{
public:
	static void DrawRect(int left, int right, int bottom, int top, int color, JNIEnv* env);
};