#pragma once

class Block
{
public:
	int GetID(JNIEnv* env);
	bool IsAir(JNIEnv* env);
};