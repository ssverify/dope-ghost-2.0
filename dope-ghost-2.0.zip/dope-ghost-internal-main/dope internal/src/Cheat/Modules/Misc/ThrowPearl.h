#pragma once
#include "../Module.h"

class ThrowPearl : public Module
{
	virtual void Run(JNIEnv* env) override;
};