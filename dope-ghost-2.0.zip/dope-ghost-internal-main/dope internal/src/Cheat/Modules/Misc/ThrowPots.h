#pragma once
#include "../Module.h"

class ThrowPots : public Module
{
	virtual void Run(JNIEnv* env) override;
};