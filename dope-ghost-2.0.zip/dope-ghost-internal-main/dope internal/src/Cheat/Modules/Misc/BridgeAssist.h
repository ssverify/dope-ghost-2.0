#pragma once
#include "../Module.h"

class BridgeAssist : public Module
{
	virtual void Run(JNIEnv* env) override;
};