#pragma once
#include "../Module.h"

class Velocity : public Module
{
	virtual void Run(JNIEnv* env) override;
};