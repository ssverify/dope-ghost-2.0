﻿#pragma once
#include "../Module.h"

class LeftClicker : public Module
{
    virtual void Run(JNIEnv* env) override;
};
