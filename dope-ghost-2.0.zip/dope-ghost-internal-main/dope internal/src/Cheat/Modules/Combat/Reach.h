#pragma once
#include "../Module.h"

class Reach : public Module
{
	virtual void Run(JNIEnv* env) override;
};