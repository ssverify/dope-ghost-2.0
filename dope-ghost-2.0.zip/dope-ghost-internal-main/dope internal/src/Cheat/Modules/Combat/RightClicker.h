#pragma once
#include "../Module.h"

class RightClicker : public Module
{
	virtual void Run(JNIEnv* env) override;
};
