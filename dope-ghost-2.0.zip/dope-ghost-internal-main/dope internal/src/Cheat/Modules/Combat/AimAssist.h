﻿#pragma once
#include "../Module.h"

class AimAssist : public Module
{
    virtual void Run(JNIEnv* env) override;
};