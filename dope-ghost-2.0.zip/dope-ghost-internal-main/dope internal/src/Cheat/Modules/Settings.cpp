#include "pch.h"
#include "Settings.h"

GameVersions g_GameVersion;