#pragma once

bool __stdcall wglSwapBuffersHook(HDC hdc);