#pragma once

struct Vec4
{
	float x, y,z,w;
};